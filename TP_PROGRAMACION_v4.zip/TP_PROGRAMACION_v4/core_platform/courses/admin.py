from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import (
    User, 
    Course, 
    Module, 
    Lesson, 
    Enrollment, 
    LessonProgress, 
    Question, 
    Choice, 
    Review
)


# ==========================================
# CONFIGURACIÓN DE USUARIOS
# ==========================================

class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Información de Rol', {'fields': ('role', 'bio', 'avatar')}),
    )


# ==========================================
# CONFIGURACIÓN DE EVALUACIONES (QUIZZES)
# ==========================================

class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 3


class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'lesson')
    list_filter = ('lesson',)
    inlines = [ChoiceInline]


# ==========================================
# CONFIGURACIÓN DE RESEÑAS (REVIEWS)
# ==========================================

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('course', 'student', 'rating', 'created_at')
    list_filter = ('rating', 'course')
    search_fields = ('student__username', 'comment')


# ==========================================
# REGISTRO DE MODELOS
# ==========================================

admin.site.register(User, CustomUserAdmin)
admin.site.register(Course)
admin.site.register(Module)
admin.site.register(Lesson)
admin.site.register(Enrollment)
admin.site.register(LessonProgress)
admin.site.register(Question, QuestionAdmin)