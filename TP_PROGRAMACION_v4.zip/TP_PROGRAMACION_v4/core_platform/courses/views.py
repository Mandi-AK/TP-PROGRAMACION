import io
from datetime import datetime

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, Http404
from django.template.loader import get_template
from django.db.models import Count, Avg

from xhtml2pdf import pisa

from .models import Course, Enrollment, Lesson, LessonProgress, Module


# ==========================================
# VISTAS PÚBLICAS DE CURSOS
# ==========================================

def course_list(request):
    courses = Course.objects.all()
    return render(request, 'courses/course_list.html', {'courses': courses})

def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    modules = course.modules.all().prefetch_related('lessons')
    
    is_enrolled = False
    if request.user.is_authenticated and request.user.role == 'student':
        is_enrolled = Enrollment.objects.filter(student=request.user, course=course).exists()

    context = {
        'course': course,
        'modules': modules,
        'is_enrolled': is_enrolled,
    }
    return render(request, 'courses/course_detail.html', context)


# ==========================================
# GESTIÓN DE INSCRIPCIONES
# ==========================================

@login_required
def enroll_in_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    if request.user.role != 'student':
        return redirect('course_detail', course_id=course.id)

    enrollment, created = Enrollment.objects.get_or_create(student=request.user, course=course)
    
    if created:
        for module in course.modules.all():
            for lesson in module.lessons.all():
                LessonProgress.objects.get_or_create(enrollment=enrollment, lesson=lesson)
                
    return redirect('student_course_view', course_id=course.id)


# ==========================================
# VISTA DEL AULA VIRTUAL (PANTALLA DE ESTUDIO)
# ==========================================

@login_required
def student_course_view(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    enrollment = Enrollment.objects.filter(student=request.user, course=course, is_paid=True).first()
    
    if not enrollment:
        messages.warning(request, "Debes comprar este curso para acceder al contenido.")
        return redirect('checkout_payment', course_id=course.id)
    
    modules = course.modules.all().prefetch_related('lessons')
    
    lesson_id = request.GET.get('lesson')
    current_lesson = None
    
    if lesson_id:
        current_lesson = get_object_or_404(Lesson, id=lesson_id, module__course=course)
    else:
        first_module = modules.first()
        if first_module:
            current_lesson = first_module.lessons.first()

    if current_lesson and current_lesson.lesson_type in ['text', 'video']:
        progress_record = LessonProgress.objects.filter(enrollment=enrollment, lesson=current_lesson).first()
        if progress_record and not progress_record.is_completed:
            progress_record.is_completed = True
            progress_record.save()

    total_lessons = LessonProgress.objects.filter(enrollment=enrollment).count()
    completed_lessons = LessonProgress.objects.filter(enrollment=enrollment, is_completed=True).count()
    
    progress_percentage = 0
    if total_lessons > 0:
        progress_percentage = int((completed_lessons / total_lessons) * 100)
        
    if progress_percentage == 100 and not enrollment.is_completed:
        enrollment.is_completed = True
        enrollment.save()

    reviews_data = course.reviews.aggregate(
        promedio=Avg('rating'),
        total=Count('id')
    )
    
    rating_promedio = round(reviews_data['promedio'], 1) if reviews_data['promedio'] else 0.0
    total_reviews = reviews_data['total']

    recent_reviews = course.reviews.select_related('student').all()[:5]

    user_review = course.reviews.filter(student=request.user).first()

    context = {
        'course': course,
        'modules': modules,
        'current_lesson': current_lesson,
        'progress_percentage': progress_percentage,
        'rating_promedio': rating_promedio,
        'total_reviews': total_reviews,
        'recent_reviews': recent_reviews,
        'user_review': user_review,
    }
    
    return render(request, 'courses/classroom.html', context)


# ==========================================
# SISTEMA DE EVALUACIONES (QUIZZES)
# ==========================================

@login_required
def take_quiz(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id, lesson_type='quiz')
    course = lesson.module.course
    enrollment = get_object_or_404(Enrollment, student=request.user, course=course)
    
    questions = lesson.questions.all().prefetch_related('choices')
    
    if request.method == 'POST':
        correct_answers_count = 0
        total_questions = questions.count()
        
        for question in questions:
            selected_choice_id = request.POST.get(f'question_{question.id}')
            if selected_choice_id:
                from .models import Choice
                choice = Choice.objects.filter(id=selected_choice_id, question=question).first()
                if choice and choice.is_correct:
                    correct_answers_count += 1
        
        if total_questions > 0 and correct_answers_count == total_questions:
            progress_record = LessonProgress.objects.filter(enrollment=enrollment, lesson=lesson).first()
            if progress_record:
                progress_record.is_completed = True
                progress_record.save()
            return redirect('student_course_view', course_id=course.id)
        else:
            return render(request, 'courses/quiz_form.html', {
                'lesson': lesson,
                'questions': questions,
                'error': "No has respondido todas las preguntas correctamente. ¡Vuelve a intentarlo!"
            })

    return render(request, 'courses/quiz_form.html', {'lesson': lesson, 'questions': questions})


# ==========================================
# SISTEMA DE AUTENTICACIÓN (LOGIN Y LOGOUT)
# ==========================================

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, f"¡Bienvenido, {username}!")
                
                if hasattr(user, 'role') and user.role == 'instructor':
                    return redirect('instructor_dashboard')
                else:
                    return redirect('course_list')
            else:
                messages.error(request, "Usuario o contraseña incorrectos.")
        else:
            messages.error(request, "Información inválida.")
    else:
        form = AuthenticationForm()
        
    return render(request, 'courses/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "Sesión cerrada correctamente.")
    return redirect('login')


# ==========================================
# GESTIÓN DE REGISTRO DE USUARIOS
# ==========================================

from .forms import CustomUserCreationForm

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            messages.success(request, "¡Cuenta creada con éxito! Ya puedes iniciar sesión.")
            return redirect('login')
        else:
            messages.error(request, "Hubo un error en el registro. Por favor, revisa los datos.")
    else:
        form = CustomUserCreationForm()
        
    return render(request, 'courses/register.html', {'form': form})


# ==========================================
# PANEL DEL INSTRUCTOR (DASHBOARD)
# ==========================================

@login_required
def instructor_dashboard(request):
    if request.user.role != 'instructor':
        messages.error(request, "No tienes permisos de instructor para acceder a esta sección.")
        return redirect('course_list')
    
    my_courses = Course.objects.filter(instructor=request.user).annotate(
        total_students=Count('enrollments', distinct=True),
        total_modules=Count('modules', distinct=True)
    )
    
    total_courses_count = my_courses.count()
    
    total_global_students = Enrollment.objects.filter(course__instructor=request.user).count()
    
    avg_progress = LessonProgress.objects.filter(
        enrollment__course__instructor=request.user
    ).aggregate(
        promedio=Avg('is_completed')
    )
    
    global_average_percentage = 0
    if avg_progress['promedio'] is not None:
        global_average_percentage = int(avg_progress['promedio'] * 100)
    
    context = {
        'courses': my_courses,
        'total_courses_count': total_courses_count,
        'total_global_students': total_global_students,
        'global_average_percentage': global_average_percentage,
    }
    return render(request, 'courses/instructor_dashboard.html', context)


# ==========================================
# CREACIÓN Y GESTIÓN DE CURSOS (INSTRUCTORES)
# ==========================================

from .forms import CourseForm

@login_required
def create_course(request):
    if request.user.role != 'instructor':
        messages.error(request, "Solo los instructores pueden crear cursos.")
        return redirect('course_list')

    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save(commit=False)
            course.instructor = request.user 
            course.save()
            messages.success(request, f"¡El curso '{course.title}' fue creado con éxito!")
            return redirect('instructor_dashboard')
    else:
        form = CourseForm()

    return render(request, 'courses/create_course.html', {'form': form})


# ==========================================
# GESTIÓN DE CONTENIDOS (MÓDULOS Y LECCIONES)
# ==========================================

from .forms import ModuleForm, LessonForm
from .models import Module

@login_required
def manage_course_content(request, course_id):
    if request.user.role != 'instructor':
        messages.error(request, "Acceso denegado.")
        return redirect('course_list')
        
    course = get_object_or_404(Course, id=course_id, instructor=request.user)
    modules = course.modules.all().prefetch_related('lessons')
    
    module_form = ModuleForm()
    lesson_form = LessonForm()
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'add_module':
            form = ModuleForm(request.POST)
            if form.is_valid():
                module = form.save(commit=False)
                module.course = course
                module.save()
                messages.success(request, f"¡Módulo '{module.title}' añadido!")
                return redirect('manage_course_content', course_id=course.id)
                
        elif action == 'add_lesson':
            form = LessonForm(request.POST, request.FILES)
            module_id = request.POST.get('module_id')
            selected_module = get_object_or_404(Module, id=module_id, course=course)
            
            if form.is_valid():
                lesson = form.save(commit=False)
                lesson.module = selected_module
                lesson.save()
                
                enrollments = course.enrollments.all()
                
                for enrollment in enrollments:
                    LessonProgress.objects.get_or_create(
                        enrollment=enrollment,
                        lesson=lesson,
                        defaults={'is_completed': False}
                    )
                
                messages.success(request, f"¡Lección '{lesson.title}' añadida con éxito!")
                return redirect('manage_course_content', course_id=course.id)

    context = {
        'course': course,
        'modules': modules,
        'module_form': module_form,
        'lesson_form': lesson_form,
    }
    return render(request, 'courses/manage_contents.html', context)


# ==========================================
# CREACIÓN DE PREGUNTAS PARA EXÁMENES (QUIZZES)
# ==========================================

from .forms import QuestionForm, ChoiceFormSet
from .models import Lesson

@login_required
def create_quiz_question(request, lesson_id):
    if request.user.role != 'instructor':
        messages.error(request, "Acceso denegado.")
        return redirect('course_list')
    
    lesson = get_object_or_404(Lesson, id=lesson_id, lesson_type='quiz', module__course__instructor=request.user)
    
    if request.method == 'POST':
        question_form = QuestionForm(request.POST)
        formset = ChoiceFormSet(request.POST)
        
        if question_form.is_valid() and formset.is_valid():
            question = question_form.save(commit=False)
            question.lesson = lesson
            question.save()
            
            choices = formset.save(commit=False)
            for choice in choices:
                choice.question = question
                choice.save()
                
            messages.success(request, f"¡Pregunta añadida con éxito a '{lesson.title}'!")
            return redirect('manage_course_content', course_id=lesson.module.course.id)
    else:
        question_form = QuestionForm()
        formset = ChoiceFormSet()
        
    context = {
        'lesson': lesson,
        'question_form': question_form,
        'formset': formset,
    }
    return render(request, 'courses/create_quiz_question.html', context)


# ==========================================
# GESTIÓN DE VALORACIONES Y RESEÑAS (REVIEWS)
# ==========================================

from django.db.models import Avg, Count
from .forms import ReviewForm
from .models import Review, Enrollment

@login_required
def add_review(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    enrollment_exists = Enrollment.objects.filter(student=request.user, course=course).exists()
    if not enrollment_exists:
        messages.error(request, "Debes estar inscrito en este curso para dejar una reseña.")
        return redirect('student_course_view', course_id=course.id)
    
    existing_review = Review.objects.filter(course=course, student=request.user).first()
    
    if request.method == 'POST':
        if existing_review:
            form = ReviewForm(request.POST, instance=existing_review)
        else:
            form = ReviewForm(request.POST)
            
        if form.is_valid():
            review = form.save(commit=False)
            review.course = course
            review.student = request.user
            review.save()
            messages.success(request, "¡Tu reseña fue guardada con éxito!")
            return redirect('student_course_view', course_id=course.id)
    else:
        form = ReviewForm(instance=existing_review) if existing_review else ReviewForm()
        
    context = {
        'course': course,
        'form': form,
        'existing_review': existing_review
    }
    return render(request, 'courses/add_review.html', context)


# ==========================================
# GENERACIÓN DE CERTIFICADOS EN PDF
# ==========================================

@login_required
def generate_certificate(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    enrollment = get_object_or_404(Enrollment, student=request.user, course=course)
    
    total_lessons = course.modules.all().prefetch_related('lessons').values_list('lessons__id', flat=True).distinct().count()
    
    if total_lessons == 0:
        raise Http404("El curso no contiene lecciones.")

    from .models import LessonProgress
    
    completed_lessons = LessonProgress.objects.filter(
        enrollment=enrollment, 
        lesson__module__course=course, 
        is_completed=True
    ).count()
    
    progress_percentage = int((completed_lessons / total_lessons) * 100) if total_lessons > 0 else 0
    
    if progress_percentage < 100:
        return HttpResponse("Para descargar el certificado debes completar el 100% del curso.", status=403)
    
    context = {
        'student_name': f"{request.user.first_name} {request.user.last_name}" if request.user.first_name else request.user.username,
        'course_title': course.title,
        'date': datetime.now().strftime('%d de %B de %Y'),
    }
    
    template = get_template('courses/certificate_pdf.html')
    html = template.render(context)
    
    result = io.BytesIO()
    pdf = pisa.pisaDocument(io.BytesIO(html.encode("UTF-8")), result)
    
    if not pdf.err:
        response = HttpResponse(result.getvalue(), content_type='application/pdf')
        filename = f"Certificado_{course.title.replace(' ', '_')}.pdf"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        return response
        
    return HttpResponse("Ocurrió un error al generar el certificado.", status=500)


# ==========================================
# PASARELA Y PROCESAMIENTO DE PAGOS (SIMULADOS)
# ==========================================

@login_required
def checkout_payment(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    if course.price == 0:
        enrollment, created = Enrollment.objects.get_or_create(
            student=request.user,
            course=course,
            defaults={'is_paid': True}
        )
        if not enrollment.is_paid:
            enrollment.is_paid = True
            enrollment.save()
            
        messages.success(request, f"Te has inscrito gratis al curso: {course.title}")
        return redirect('student_course_view', course_id=course.id)

    existing_enrollment = Enrollment.objects.filter(student=request.user, course=course).first()
    if existing_enrollment and existing_enrollment.is_paid:
        return redirect('student_course_view', course_id=course.id)

    if request.method == 'POST':
        card_name = request.POST.get('card_name')
        card_number = request.POST.get('card_number')
        
        if not card_name or not card_number:
            messages.error(request, "Por favor, completa todos los datos requeridos de tu tarjeta.")
        else:
            enrollment, created = Enrollment.objects.get_or_create(
                student=request.user,
                course=course
            )
            enrollment.is_paid = True
            enrollment.save()

            for module in course.modules.all():
                for lesson in module.lessons.all():
                    LessonProgress.objects.get_or_create(
                        enrollment=enrollment,
                        lesson=lesson,
                        defaults={'is_completed': False}
                    )

            messages.success(request, f"¡Pago de ${course.price} procesado con éxito! Ya puedes acceder a las clases.")
            return redirect('student_course_view', course_id=course.id)

    context = {
        'course': course,
    }
    return render(request, 'courses/checkout.html', context)