from django.urls import path
from . import views

urlpatterns = [
    # ==========================================
    # RUTAS PÚBLICAS DE CURSOS
    # ==========================================
    path('', views.course_list, name='course_list'),
    path('course/<int:course_id>/', views.course_detail, name='course_detail'),
    
    # ==========================================
    # GESTIÓN DE INSCRIPCIONES Y AULA VIRTUAL
    # ==========================================
    path('course/<int:course_id>/enroll/', views.enroll_in_course, name='enroll_in_course'),
    path('course/<int:course_id>/classroom/', views.student_course_view, name='student_course_view'),
    path('quiz/<int:lesson_id>/', views.take_quiz, name='take_quiz'),

    # ==========================================
    # AUTENTICACIÓN Y REGISTRO DE USUARIOS
    # ==========================================
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),

    # ==========================================
    # PANEL DE INSTRUCTOR (DASHBOARD)
    # ==========================================
    path('instructor/dashboard/', views.instructor_dashboard, name='instructor_dashboard'),
    path('instructor/course/new/', views.create_course, name='create_course'), 

    # ==========================================
    # GESTIÓN DE CONTENIDOS (MÓDULOS Y LECCIONES)
    # ==========================================
    path('instructor/course/<int:course_id>/manage/', views.manage_course_content, name='manage_course_content'),
    path('lesson/<int:lesson_id>/add-question/', views.create_quiz_question, name='create_quiz_question'),

    # ==========================================
    # RESEÑAS, CERTIFICADOS Y PAGOS
    # ==========================================
    path('course/<int:course_id>/add-review/', views.add_review, name='add_review'),
    path('course/<int:course_id>/certificate/', views.generate_certificate, name='generate_certificate'),
    path('course/<int:course_id>/checkout/', views.checkout_payment, name='checkout_payment'),
]
