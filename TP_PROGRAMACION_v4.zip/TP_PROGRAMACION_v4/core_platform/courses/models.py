from django.db import models
from django.contrib.auth.models import AbstractUser


# ==========================================
# MODELO DE USUARIO PERSONALIZADO
# ==========================================

class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Administrador'),
        ('instructor', 'Instructor'),
        ('student', 'Estudiante'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='student')
    bio = models.TextField(blank=True, null=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)

    def is_instructor(self):
        return self.role == 'instructor' or self.is_staff

    def is_student(self):
        return self.role == 'student'

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"


# ==========================================
# ESTRUCTURA ACADÉMICA DE LOS CURSOS
# ==========================================

class Course(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    instructor = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'role': 'instructor'}, related_name='courses_taught')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class Module(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='modules')
    title = models.CharField(max_length=255)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.course.title} - Módulo: {self.title}"


class Lesson(models.Model):
    LESSON_TYPES = (
        ('video', 'Video'),
        ('text', 'Texto'),
        ('quiz', 'Quiz'),
    )
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=255)
    lesson_type = models.CharField(max_length=10, choices=LESSON_TYPES)
    content_text = models.TextField(blank=True, null=True)
    video_file = models.FileField(upload_to='videos/', blank=True, null=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.module.title} - Lección: {self.title} ({self.get_lesson_type_display()})"


# ==========================================
# INSCRIPCIONES Y SEGUIMIENTO DE PROGRESO
# ==========================================

class Enrollment(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'role': 'student'}, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    enrolled_at = models.DateTimeField(auto_now_add=True)
    is_completed = models.BooleanField(default=False)
    is_paid = models.BooleanField(default=False, verbose_name="Pagado")

    class Meta:
        unique_together = ('student', 'course')

    def __str__(self):
        return f"{self.student.username} inscrito en {self.course.title} ({'Pagado' if self.is_paid else 'Pendiente de Pago'})"


class LessonProgress(models.Model):
    enrollment = models.ForeignKey(Enrollment, on_delete=models.CASCADE, related_name='lesson_progress')
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name='progress_records')
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        unique_together = ('enrollment', 'lesson')

    def __str__(self):
        return f"{self.enrollment.student.username} - {self.lesson.title}: {'Hecho' if self.is_completed else 'Pendiente'}"


# ==========================================
# SISTEMA DE EVALUACIONES (QUIZZES)
# ==========================================

class Question(models.Model):
    lesson = models.ForeignKey(
        Lesson, 
        on_delete=models.CASCADE, 
        limit_choices_to={'lesson_type': 'quiz'}, 
        related_name='questions'
    )
    text = models.TextField(verbose_name="Pregunta")

    def __str__(self):
        return f"Pregunta ({self.lesson.title}): {self.text[:50]}..."


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='choices')
    text = models.CharField(max_length=255, verbose_name="Opción de respuesta")
    is_correct = models.BooleanField(default=False, verbose_name="¿Es la respuesta correcta?")

    def __str__(self):
        return f"{self.text} ({'Correcta' if self.is_correct else 'Incorrecta'})"


# ==========================================
# SISTEMA DE RESEÑAS (REVIEWS)
# ==========================================

class Review(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='reviews')
    student = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'role': 'student'})
    rating = models.PositiveSmallIntegerField(
        choices=[(i, f"{i} Estrella{'s' if i > 1 else ''}") for i in range(1, 6)],
        verbose_name="Calificación"
    )
    comment = models.TextField(verbose_name="Comentario", blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('course', 'student')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.student.username} - {self.course.title}: {self.rating}★"