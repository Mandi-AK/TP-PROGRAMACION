from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.forms import inlineformset_factory

from .models import Course, Module, Lesson, Question, Choice, Review

User = get_user_model()


# ==========================================
# REGISTRO Y AUTENTICACIÓN DE USUARIOS
# ==========================================

class CustomUserCreationForm(UserCreationForm):
    ROLE_CHOICES = [
        ('student', 'Estudiante'),
        ('instructor', 'Instructor'),
    ]
    
    role = forms.ChoiceField(
        choices=ROLE_CHOICES, 
        label="Registrarme como",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    avatar = forms.ImageField(
        required=False,
        label="Foto de perfil (Opcional)",
        widget=forms.FileInput(attrs={'class': 'form-control'})
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('role', 'avatar')


# ==========================================
# GESTIÓN DE CURSOS
# ==========================================

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description', 'price'] 
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej. Introducción a Python'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': '¿De qué trata el curso?'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'placeholder': 'Ej. 0.00 si es gratis'}),
        }


# ==========================================
# GESTIÓN DE CONTENIDOS (MÓDULOS Y LECCIONES)
# ==========================================

class ModuleForm(forms.ModelForm):
    class Meta:
        model = Module
        fields = ['title', 'order']
        labels = {
            'title': 'Nombre del Módulo',
            'order': 'Orden / Posición (Ej: 1, 2, 3)',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej. Módulo 1: Fundamentos'}),
            'order': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
        }


class LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = ['title', 'lesson_type', 'content_text', 'video_file', 'order']
        labels = {
            'title': 'Título de la Clase',
            'lesson_type': 'Tipo de Contenido',
            'content_text': 'Contenido de Texto (Opcional)',
            'video_file': 'Archivo de Video (Opcional)',
            'order': 'Orden / Posición',
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej. Introducción a las Variables'}),
            'lesson_type': forms.Select(attrs={'class': 'form-control'}),
            'content_text': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Escribe aquí la clase si es de tipo texto...'}),
            'video_file': forms.FileInput(attrs={'class': 'form-control'}),
            'order': forms.NumberInput(attrs={'class': 'form-control', 'min': '0'}),
        }


# ==========================================
# SISTEMA DE EVALUACIONES (QUIZZES)
# ==========================================

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['text']
        widgets = {
            'text': forms.TextInput(attrs={
                'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm',
                'placeholder': 'Escribí la pregunta aquí...'
            }),
        }


ChoiceFormSet = inlineformset_factory(
    Question, 
    Choice, 
    fields=['text', 'is_correct'],
    extra=4,            
    can_delete=False,    
    widgets={
        'text': forms.TextInput(attrs={
            'class': 'w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm',
            'placeholder': 'Escribí una opción...'
        }),
        'is_correct': forms.CheckboxInput(attrs={
            'class': 'w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500'
        })
    }
)


# ==========================================
# SISTEMA DE RESEÑAS (REVIEWS)
# ==========================================

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['rating', 'comment']
        widgets = {
            'rating': forms.Select(attrs={
                'class': 'w-full px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm bg-white'
            }),
            'comment': forms.Textarea(attrs={
                'class': 'w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm',
                'placeholder': '¿Qué te pareció el curso? Compartí tu experiencia...',
                'rows': 4
            }),
        }