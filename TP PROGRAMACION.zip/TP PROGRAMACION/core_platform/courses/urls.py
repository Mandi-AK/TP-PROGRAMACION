from django.urls import path
from . import views

urlpatterns = [
    path('', views.course_list, name='course_list'),
    path('course/<int:course_id>/', views.course_detail, name='course_detail'),
    
    # NUEVAS RUTAS
    path('course/<int:course_id>/enroll/', views.enroll_in_course, name='enroll_in_course'),
    path('course/<int:course_id>/classroom/', views.student_course_view, name='student_course_view'),
    path('quiz/<int:lesson_id>/', views.take_quiz, name='take_quiz'),
]
