from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Course, Module, Lesson, Enrollment, LessonProgress, Question, Choice

class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Información de Rol', {'fields': ('role', 'bio', 'avatar')}),
    )

class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 3

class QuestionAdmin(admin.ModelAdmin):
    inlines = [ChoiceInline]

admin.site.register(User, CustomUserAdmin)
admin.site.register(Course)
admin.site.register(Module)
admin.site.register(Lesson)
admin.site.register(Enrollment)
admin.site.register(LessonProgress)
admin.site.register(Question, QuestionAdmin)