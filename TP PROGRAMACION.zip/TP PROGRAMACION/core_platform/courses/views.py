from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Course, Enrollment, Lesson, LessonProgress

def course_list(request):
    courses = Course.objects.all()
    return render(request, 'courses/course_list.html', {'courses': courses})

def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    modules = course.modules.all().prefetch_related('lessons')
    
    # Verificamos si el usuario actual ya está inscrito para cambiar el botón en el HTML
    is_enrolled = False
    if request.user.is_authenticated and request.user.role == 'student':
        is_enrolled = Enrollment.objects.filter(student=request.user, course=course).exists()

    context = {
        'course': course,
        'modules': modules,
        'is_enrolled': is_enrolled,
    }
    return render(request, 'courses/course_detail.html', context)


# --- NUEVA LÓGICA DE INSCRIPCIÓN ---

@login_required
def enroll_in_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Forzar a que solo los usuarios con rol 'student' se inscriban
    if request.user.role != 'student':
        return redirect('course_detail', course_id=course.id)

    # Crear la inscripción si no existe
    enrollment, created = Enrollment.objects.get_or_create(student=request.user, course=course)
    
    if created:
        # Si es una inscripción nueva, le creamos un registro de progreso para CADA lección del curso
        for module in course.modules.all():
            for lesson in module.lessons.all():
                LessonProgress.objects.get_or_create(enrollment=enrollment, lesson=lesson)
                
    # Lo mandamos directo a que empiece a estudiar el curso
    return redirect('student_course_view', course_id=course.id)


# --- LA VISTA DE LA CLASE (PANTALLA DE ESTUDIO) ---

@login_required
def student_course_view(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    enrollment = get_object_or_404(Enrollment, student=request.user, course=course)
    
    # Traer el temario
    modules = course.modules.all().prefetch_related('lessons')
    
    # Obtener qué lección quiere ver el alumno (por defecto la primera del curso)
    lesson_id = request.GET.get('lesson')
    current_lesson = None
    
    if lesson_id:
        current_lesson = get_object_or_404(Lesson, id=lesson_id, module__course=course)
    else:
        # Si no seleccionó ninguna clase, buscamos la primera lección del primer módulo
        first_module = modules.first()
        if first_module:
            current_lesson = first_module.lessons.first()

    # Si la lección actual es de texto o video, la marcamos como completada automáticamente al verla
    if current_lesson and current_lesson.lesson_type in ['text', 'video']:
        progress_record = LessonProgress.objects.filter(enrollment=enrollment, lesson=current_lesson).first()
        if progress_record and not progress_record.is_completed:
            progress_record.is_completed = True
            progress_record.save()

    # Calcular el porcentaje de progreso del alumno en este curso
    total_lessons = LessonProgress.objects.filter(enrollment=enrollment).count()
    completed_lessons = LessonProgress.objects.filter(enrollment=enrollment, is_completed=True).count()
    
    progress_percentage = 0
    if total_lessons > 0:
        progress_percentage = int((completed_lessons / total_lessons) * 100)
        
    # Si llegó al 100%, actualizamos el estado de la inscripción
    if progress_percentage == 100 and not enrollment.is_completed:
        enrollment.is_completed = True
        enrollment.save()

    context = {
        'course': course,
        'modules': modules,
        'current_lesson': current_lesson,
        'progress_percentage': progress_percentage,
    }
    return render(request, 'courses/student_view.html', context)

# --- LÓGICA DEL SISTEMA DE QUIZZES ---

@login_required
def take_quiz(request, lesson_id):
    # Buscamos la lección que debe ser obligatoriamente tipo quiz
    lesson = get_object_or_404(Lesson, id=lesson_id, lesson_type='quiz')
    course = lesson.module.course
    enrollment = get_object_or_404(Enrollment, student=request.user, course=course)
    
    # Traemos las preguntas asociadas a esta lección con sus opciones
    questions = lesson.questions.all().prefetch_related('choices')
    
    if request.method == 'POST':
        correct_answers_count = 0
        total_questions = questions.count()
        
        for question in questions:
            # Obtenemos la opción seleccionada por el alumno para esta pregunta
            selected_choice_id = request.POST.get(f'question_{question.id}')
            if selected_choice_id:
                from .models import Choice
                choice = Choice.objects.filter(id=selected_choice_id, question=question).first()
                # Si la opción es la marcada como correcta, sumamos un punto
                if choice and choice.is_correct:
                    correct_answers_count += 1
        
        # Para aprobar el TP/Quiz, requerimos que responda el 100% bien (puedes cambiarlo a > 70% si quieres)
        if total_questions > 0 and correct_answers_count == total_questions:
            progress_record = LessonProgress.objects.filter(enrollment=enrollment, lesson=lesson).first()
            if progress_record:
                progress_record.is_completed = True
                progress_record.save()
            return redirect('student_course_view', course_id=course.id)
        else:
            # Si reprobó, volvemos a mostrar el examen con un mensaje de error
            return render(request, 'courses/quiz_form.html', {
                'lesson': lesson,
                'questions': questions,
                'error': "No has respondido todas las preguntas correctamente. ¡Vuelve a intentarlo!"
            })

    return render(request, 'courses/quiz_form.html', {'lesson': lesson, 'questions': questions})